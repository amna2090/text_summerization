import streamlit as st
import pandas as pd
from docx import Document
from summarizer import summarize_text

st.title("AI Text Summarization Tool")

uploaded_file = st.file_uploader("Upload a text, CSV, or Word file", type=["txt", "csv", "docx"])

if uploaded_file:
    text = ""

    # Read text from uploaded file
    if uploaded_file.name.endswith(".txt"):
        text = uploaded_file.read().decode("utf-8")
    elif uploaded_file.name.endswith(".docx"):
        doc = Document(uploaded_file)
        text = "\n".join([para.text for para in doc.paragraphs])
    elif uploaded_file.name.endswith(".csv"):
        data = pd.read_csv(uploaded_file)
        text_col = st.selectbox("Select the column to summarize", data.columns)
        text = " ".join(data[text_col].astype(str))

    st.subheader("Original Text Sample")
    st.write(text[:1000] + "...")

    # User options
    num_sentences = st.slider("Select number of sentences for summary", 1, 15, 5)
    correct_words = st.checkbox("Enable word correction (slow for large text)")

    correct_words_flag = correct_words 
    summary = summarize_text(text, num_sentences=num_sentences, correct_words=correct_words_flag)



    st.subheader("Summarized Text")
    st.markdown(summary.replace("\n", "<br>"), unsafe_allow_html=True)

    # Download button
    st.download_button(
        label="Download Summary as TXT",
        data=summary,
        file_name="summary.txt",
        mime="text/plain"
    )
