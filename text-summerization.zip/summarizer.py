import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from textblob import TextBlob
import re

# Download NLTK resources once
nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)

def chunk_text(text, chunk_size=1500):
    """Split large text into smaller chunks of approximately chunk_size characters."""
    return [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]

skip_terms = ["TCP/IP", "VLAN", "SDN", "BGP", "MPLS", "QoS", "IDS/IPS", "VPN"]
def is_safe_word(word):
    return not re.search(r"[A-Z0-9/:@]", word) and word not in skip_terms


def correct_text_skip_links(text):
    """
    Corrects text using TextBlob but skips URLs and technical terms.
    """
    url_pattern = r'(https?://\S+|www\.\S+)'
    parts = re.split(f'({url_pattern})', text)

    corrected_parts = []
    for part in parts:
        if re.match(url_pattern, part):
            corrected_parts.append(part)
        else:
            # Correct only safe words
            corrected_words = [
                str(TextBlob(w).correct()) if is_safe_word(w) else w
                for w in part.split()
            ]
            corrected_parts.append(" ".join(corrected_words))

    return "".join(corrected_parts)

def summarize_text(text, num_sentences=5, correct_words=False):
    """
    Extractive summarization.
    Returns a numbered summary in original sentence order.
    """
    if correct_words:
        text = correct_text_skip_links(text)

    sentences = sent_tokenize(text)

    if len(sentences) <= num_sentences:
        return "\n\n".join([f"{i+1}. {s}" for i, s in enumerate(sentences)])

    stop_words = set(stopwords.words("english"))
    words = [w.lower() for w in word_tokenize(text) if w.isalnum() and w.lower() not in stop_words]

    word_freq = {}
    for w in words:
        word_freq[w] = word_freq.get(w, 0) + 1

    sentence_scores = {}
    for sent in sentences:
        score = sum(word_freq.get(w.lower(), 0) for w in word_tokenize(sent))
        sentence_scores[sent] = score

    # Select top sentences
    top_sentences = sorted(sentence_scores, key=sentence_scores.get, reverse=True)[:num_sentences]

    # Preserve original order
    top_set = set(top_sentences)
    ordered_summary = [s for s in sentences if s in top_set]

    summary = "\n\n".join([f"{i+1}. {s}" for i, s in enumerate(ordered_summary)])
    return summary
